package net.scalax.simple.wire
package model

case class Cat(id: Int, name: String, age: Int)
