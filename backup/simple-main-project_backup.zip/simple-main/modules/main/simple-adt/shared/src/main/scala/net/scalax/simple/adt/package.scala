package net.scalax.simple

package object adt {

  val TypeAdt: impl.Adt.type = impl.Adt

}
