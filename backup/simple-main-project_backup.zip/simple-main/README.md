# simple

[![Maven Central](https://img.shields.io/maven-central/v/net.scalax.simple/simple-adt_3.svg?label=Maven%20Central)](https://search.maven.org/search?q=g:%22net.scalax.simple%22%20AND%20a:%22simple-adt_3%22)

Simple, and scalable.  
Use it to subvert the author's imagination.

## Modules with documentions
### [simple-adt](./modules/main/simple-adt/)
A simple abstraction of ADT(Abstract Data Type).